import React from "react";
import { Link } from "react-router-dom";

import "./navbar.css";

const Navbar = () => {
  return (
    <div className="Navbar">
      <ul>
        {" "}
        <li className="Lis">
          <Link to="/" activeStyle>
            HOME
          </Link>
        </li>
        <li className="Lis">
          <Link to="/about" activeStyle>
            ABOUT
          </Link>
        </li>
        <li className="Lis">
          <Link to="/photo" activeStyle>
            PHOTO
          </Link>
        </li>
        <li className="Lis">
          <Link to="/resume" activeStyle>
            RESUME
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Navbar;
