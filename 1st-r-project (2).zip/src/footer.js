import React from "react";
import "./footer.css";
const About = () => {
  return (
    <div className="Suthar">
      <ul className="details">
        <li>Name:Suthar</li>
        <li>contacts no:8525906916</li>
        <li>Email:sutharthanan.v@gmail.com</li>
      </ul>
      <ul className="contact">
        <li>Address:no.xxxxxxxxx cuddalore dt, Tamilnadu, India.</li>
      </ul>
    </div>
  );
};

export default About;
