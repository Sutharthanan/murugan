import React from "react";
import { redirect } from "react-router-dom";

const About = () => {
  
  
  return (
    <div className="about">
      <h1 >hi i am suthar,currently i am search for react frontend job</h1>
    <p>if you have job vacancy feeel free to conduct me for making "best website"
      </p></div>
  );
};

export default About;
