import React from "react";
import Resume from "../photo/cv.jpg.jpg";
import "./resume.css";

const resume = () => {
  return (
    <div className="resumee">
      <img src={Resume} alt="" />
    </div>
  );
};

export default resume;
