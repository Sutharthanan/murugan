import React from "react";
import Suthar from "../photo/suthar.jpg";
import "./my-photo.css";
const photo = () => {
  return (
    <div className="sss">
      <img src={Suthar} alt="" />
    </div>
  );
};

export default photo;
