import React from "react";
import "./home.css";
import Sk from "../photo/sk.jpg";
const About = () => {
  return (
    <div style={{ backgroundImage: `url(${Sk})` }} ClassName="SLK">
      <div>
        {" "}
        <h1>welcome to my home</h1>
      </div>
    </div>
  );
};

export default About;
